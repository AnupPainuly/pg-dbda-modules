var script = document.createElement("script");
script.type = "text/javascript";
script.src = "/doc/_static/versionwarning.js";
document.head.appendChild(script);