1) In Eclipse export the jar from this project having name as inputcounties.jar
2) Make sure that the jar is at the project base folder (i.e HDFS_API)
3) Assumption is that counties folder(having *.csv files) is in the project base 
folder
4) Run the jar using following command on project base folder
yarn jar inputcounties.jar hdfs.InputCounties

